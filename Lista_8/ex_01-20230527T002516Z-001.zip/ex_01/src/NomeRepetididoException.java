public class NomeRepetididoException extends Exception {

    public NomeRepetididoException() {
    }

    public NomeRepetididoException(String message) {
        super(message);
    }
}
