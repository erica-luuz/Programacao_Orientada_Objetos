public enum Arma {
    ESPADA, LANCA, MACHADO;
}
