package com.programando.elevandonumeroaoquadrado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElevandoNumeroAoQuadradoApplicationTests {

	@Test
	void contextLoads() {
	}

}
